var i = 0;
var check=[];
var password= [[1,2,3,4,'!','@','#','$'], [7,5,8,0,1,2,3,5], [4,7,8,'!','$','*','%',3]];
var tog=0;
const indicator = document.querySelector('#indicator')
const circles = document.querySelectorAll('.circle')
function test(a){
circles[i].classList.add('light-up')
 if(i<8 && tog==0){
  switch(a){
    case 0:
      check[i]=0;
      console.log(check);
      break;
    case 1:
      check[i]=1;
      console.log(check);
      break;
    case 2:
      check[i]=2;
      console.log(check);
      break;
    case 3:
      check[i]=3;
      console.log(check);
      break;
    case 4:
      check[i]=4;
      console.log(check);
      break;
    case 5:
      check[i]=5;
      console.log(check);
      break;
    case 6:
      check[i]=6;
      console.log(check);
      break;
    case 7:
      check[i]=7;
      console.log(check);
      break;
    case 8:
      check[i]=8;
      console.log(check);
      break;
    case 9:
      check[i]=9;
      console.log(check);
      break;
  
 }
i++;
   console.log(i);
   if(i==8){
 if( isCorrectPassword(check,password[0]) ||     
  isCorrectPassword(check,password[1]) || 
  isCorrectPassword(check,password[2])){
   console.log("passed");
  }
   }
   
}
  else if(i<8 && tog==1){
    switch(a){
    case 0:
      check[i]=')';
      console.log(check);
      break;
    case 1:
      check[i]='!';
      console.log(check);
      break;
    case 2:
      check[i]='@';
      console.log(check);
      break;
    case 3:
      check[i]='#';
      console.log(check);
      break;
    case 4:
      check[i]='$';
      console.log(check);
      break;
    case 5:
      check[i]='%';
      console.log(check);
      break;
    case 6:
      check[i]="^";
      console.log(check);
      break;
    case 7:
      check[i]='&';
      console.log(check);
      break;
    case 8:
      check[i]="*";
      console.log(check);
      break;
    case 9:
      check[i]="(";
      console.log(check);
      break;
  
 }
i++;
   console.log(i);
   if(i==8){
 if( isCorrectPassword(check,password[0]) ||     
  isCorrectPassword(check,password[1]) || 
  isCorrectPassword(check,password[2])){
   console.log("passed");
  }
   }  
  }
}
function isCorrectPassword(pass1, pass2) {
    for (var i = 0; i < pass1.length; i++) {
      if (pass1[i] !== pass2[i]) {
        console.log("false");
        setTimeout(clearCircles, 200)
        i=0;
        return false;
      }
    };
  window.location.replace('https://opsystem-combine.ajacob4350.repl.co');
  console.log("yes");
    return true;
  
  };

function toggle(){
  console.log("d");
  if(tog==0){
    tog=1;
    document.getElementById('1').innerText='!';
    document.getElementById('2').innerText='@';
    document.getElementById('3').innerText='#';
    document.getElementById('4').innerText='$';
    document.getElementById('5').innerText='%';
    document.getElementById('6').innerText='^';
    document.getElementById('7').innerText='&';
    document.getElementById('8').innerText='*';
    document.getElementById('9').innerText='(';
    document.getElementById('0').innerText=')';
  }
  else{
    tog=0;
    document.getElementById('1').innerText='1';
    document.getElementById('2').innerText='2';
    document.getElementById('3').innerText='3';
    document.getElementById('4').innerText='4';
    document.getElementById('5').innerText='5';
    document.getElementById('6').innerText='6';
    document.getElementById('7').innerText='7';
    document.getElementById('8').innerText='8';
    document.getElementById('9').innerText='9';
    document.getElementById('0').innerText='0';
    
  }
}



function back(){
  if(i>0){
    circles[i-1].classList.remove('light-up')
    i--;
    console.log(check);
    console.log(i);
    
  }
}

function clearCircles() {
    for (i = 7; i > -1; i--) {
        circles[i].classList.remove('light-up')
    }
    i = 0;
    indicator.classList.add('sway')
}

function clearPassword() {
    while (selected.length > 0) {
        selected.pop()
    }
    indicator.classList.remove('sway')
}